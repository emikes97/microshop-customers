package customers.web.controllers;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class CustomerAddressController {

    // == Fields ==

    // == Constructors ==

    // == Public Methods ==

}
