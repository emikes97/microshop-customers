package customers.web.DTO.Requests.Customer;

public record DTOCustomerUpdateCredentials() {
}
