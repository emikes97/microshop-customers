package customers.web.DTO.Requests.Customer;

public record DTOCustomerUpdateCredentials(String oldPassword, String newPassword) {
}
