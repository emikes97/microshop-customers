package customers.domain.state;

public enum TokenStatus {
    PENDING,
    ACTIVE,
    PROCESSING,
    FAILED
}
