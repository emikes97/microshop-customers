package customers.domain.state;

public enum AccountStatus {
    ACTIVE,
    DEACTIVATED,
    DELETED,
    CREATED
}
